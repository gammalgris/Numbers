
See the documentation of the web server component at following location(s):

	.\Utilities\Web-Docs


Before the first start check following configuration file(s):

	CustomWebServer.properties
	startWebServer.properties


The web server expects a specific environment. Check following script(s):

	setEnv.bat
